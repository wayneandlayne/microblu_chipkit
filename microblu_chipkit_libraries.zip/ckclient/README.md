This is the initial work for a Client-style interface to DEIPcK, a pretty good networking stack for ChipKIT.

It appears to mostly work, but there is some further work that needs to be done.

Further Work
============

 * Figure out a strategy for when to do the PeriodicWork function inside the calls.
 * Implement the missing calls, like status.
 * Figure out what the MAX_SOCK_NUM thing was all about in the previous version, and see if that is functionality
     that we need to bring forward.
 * Make sure it actually works. :)
